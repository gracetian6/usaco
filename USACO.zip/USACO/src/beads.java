/*
ID: graceti1
LANG: JAVA
TASK: beads
*/

import java.io.*;
import java.util.*;
public class beads {

	/* 
	 * organizes bead info so that if beads = "RRBBBRR", 
	 * then beadType = [R,B,R] and beadCount = [2,3,2]. 
	 */
	public static void updateInfo(String beads, ArrayList<Character> beadType, ArrayList<Integer> beadCount) {
		char current = beads.charAt(0); int count = 0;
		for (int i = 0; i<beads.length(); i++) {
			if (beads.charAt(i)==current) {
				count++; 
			}
			else {
				beadType.add(current);
				beadCount.add(count);
				current = beads.charAt(i);
				count = 1;
			}	
		}
		beadType.add(current);
		beadCount.add(count);

	}
	
	/*
	 * finds the max length of a bead
	 * @param N				the total number of beads 
	 * @param beadType 		arraylist of all the type of consecutive beads 
	 * @param beadCount 	arraylist of the frequency of consecutive beadTypes 
	 * So RRBBBRR would be stored as [R,B,R] in beadType and [2,3,2] in beadCount 
	 */
	public static int findMax(ArrayList<Character> beadType, ArrayList<Integer> beadCount) {
		
		int max = 0; char first = beadType.get(0); 
		//scan through arraylist beadType, keeping a total counter using arrayList beadCount
		int i = 0; 
		while (i<beadType.size()) { //first bead at index i 
			first = beadType.get(i);
			boolean second = false, done = false; 
			int j = i, len = 0;
			//find max length for first bead 
			while (j<=beadType.size()+i-1 && !done) { //can only scan at most N times 
				char current = beadType.get(j%beadType.size()); //current bead
				char next = beadType.get((j+1)%beadType.size()); 
				
				len = len + beadCount.get(j%beadType.size());
				//when red - add up until you find blue, then continue until you find red
				if (first == 'r') {
					if (current == 'b') second = true;
					if (next == 'r' && second == true) done = true;
				}
				//when blue - add up until you find red, then continue until you find blue
				else if (first == 'b') {
					if (current == 'r') second = true; 
					if (next == 'b' && second == true) done = true;
				}
				//when white - follow instructions for the next bead 
				else if (first == 'w') {
					first = beadType.get((j+1)%beadType.size());
				}
				j++;
			}
			if (len > max) max = len; 
			i++; 
		}
		return max;
	}
	public static void main(String[] args) throws IOException{
		//read file 
		File file = new File("beads.in");
		Scanner in = new Scanner(file);
		in.nextInt(); //number of beads
		String beads = in.next();
		in.close();
		
		//arraylists that store the bead information 
		ArrayList<Character> beadType = new ArrayList<Character>();
		ArrayList<Integer> beadCount = new ArrayList<Integer>(); 
		updateInfo(beads, beadType, beadCount);
		
		int max = findMax(beadType, beadCount); 

		//output the results 
		PrintWriter out = new PrintWriter("beads.out");//output the result 
		out.println(max);
		out.close();
	}
}
